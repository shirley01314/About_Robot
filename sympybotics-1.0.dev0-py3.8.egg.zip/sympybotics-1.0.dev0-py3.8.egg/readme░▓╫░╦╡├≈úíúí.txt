安装使用说明：

1.下载包后解压(解压位置任意)
2.解压后在sympybotics的目录下cmd打开命令行
3.输入python setup.py install 
4.命令行完成后，找到电脑的python安装位置，进入到../python/Lib/site-packages/，将sympybotics-1.0.dev0-py3.8.egg.zip解压包解压到当前目录下，解压完成后删除压缩包
5.完成以上步骤，即sympy和sympybotics安装成功，即可在python的IDE内使用以上两个包

注：Dynamic_identification.py 是写好的程序样例，可打开直接运行此程序。